var class_chess_1_1_void_case =
[
    [ "VoidCase", "class_chess_1_1_void_case.html#aecd5a1b36f1c2e8ad2f5b764bd9432c6", null ],
    [ "CanMoveThere", "class_chess_1_1_void_case.html#adb48d858fa564b234f48e29f82f252e4", null ]
];