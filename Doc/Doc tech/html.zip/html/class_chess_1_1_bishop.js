var class_chess_1_1_bishop =
[
    [ "Bishop", "class_chess_1_1_bishop.html#a8c201a54479c0d852aac98757b258029", null ],
    [ "CanMoveThere", "class_chess_1_1_bishop.html#a9188ea6130092795c5b7c9efd593ce05", null ]
];