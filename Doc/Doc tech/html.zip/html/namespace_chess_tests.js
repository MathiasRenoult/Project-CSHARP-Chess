var namespace_chess_tests =
[
    [ "AdddingPieces", "class_chess_tests_1_1_addding_pieces.html", "class_chess_tests_1_1_addding_pieces" ],
    [ "InitialisingBoard", "class_chess_tests_1_1_initialising_board.html", "class_chess_tests_1_1_initialising_board" ],
    [ "MovingPieces", "class_chess_tests_1_1_moving_pieces.html", "class_chess_tests_1_1_moving_pieces" ]
];