var dir_b57d01c3a3f42ab9e1f33a883bdde504 =
[
    [ "obj", "dir_7d70fc5678bd4f0dece310607abdc8f5.html", "dir_7d70fc5678bd4f0dece310607abdc8f5" ],
    [ "Properties", "dir_30b3f3dc531e08db1ec3bd96722a184d.html", "dir_30b3f3dc531e08db1ec3bd96722a184d" ],
    [ "ChangeDBConfigForm.cs", "_change_d_b_config_form_8cs_source.html", null ],
    [ "ChangeDBConfigForm.Designer.cs", "_change_d_b_config_form_8_designer_8cs_source.html", null ],
    [ "DatabaseConfig.cs", "_i_2_database_config_8cs_source.html", null ],
    [ "GameForm.cs", "_game_form_8cs_source.html", null ],
    [ "GameForm.Designer.cs", "_game_form_8_designer_8cs_source.html", null ],
    [ "Login.cs", "_login_8cs_source.html", null ],
    [ "LoginForm.cs", "_login_form_8cs_source.html", null ],
    [ "LoginForm.Designer.cs", "_login_form_8_designer_8cs_source.html", null ],
    [ "Program.cs", "_i_2_program_8cs_source.html", null ],
    [ "Register.cs", "_register_8cs_source.html", null ],
    [ "RegisterForm.cs", "_register_form_8cs_source.html", null ],
    [ "RegisterForm.Designer.cs", "_register_form_8_designer_8cs_source.html", null ]
];