var class_chess_1_1_king =
[
    [ "King", "class_chess_1_1_king.html#a86025f69a4d6f201cc8306d096783507", null ],
    [ "CanMoveThere", "class_chess_1_1_king.html#ad20d342976dcca769c72718a2a718af2", null ],
    [ "IsChecked", "class_chess_1_1_king.html#ab397d687e6cfd48f911f6a982131b1d8", null ],
    [ "IsCheckMated", "class_chess_1_1_king.html#a12efcf63f3b36a320365654cdb3eecee", null ]
];