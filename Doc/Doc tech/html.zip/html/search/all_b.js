var searchData=
[
  ['queen_33',['Queen',['../class_chess_1_1_queen.html',1,'Chess']]]
];
