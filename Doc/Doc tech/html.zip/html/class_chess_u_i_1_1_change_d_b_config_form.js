var class_chess_u_i_1_1_change_d_b_config_form =
[
    [ "ChangeDBConfigForm", "class_chess_u_i_1_1_change_d_b_config_form.html#ae89128659cd6ef0f9de162608a66e67b", null ],
    [ "Dispose", "class_chess_u_i_1_1_change_d_b_config_form.html#a481517d1d3e122fae732004c8bb3b057", null ]
];