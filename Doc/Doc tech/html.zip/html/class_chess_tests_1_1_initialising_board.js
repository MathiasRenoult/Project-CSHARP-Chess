var class_chess_tests_1_1_initialising_board =
[
    [ "CreateAnEmptyBoard", "class_chess_tests_1_1_initialising_board.html#a6a20faaa8ee34eb134c23e3fdfa3bbcc", null ],
    [ "CreateStandardBoard", "class_chess_tests_1_1_initialising_board.html#a9bf17faaf4f26f556e9b0a369ea7a573", null ]
];