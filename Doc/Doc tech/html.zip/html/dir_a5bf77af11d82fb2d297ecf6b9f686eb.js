var dir_a5bf77af11d82fb2d297ecf6b9f686eb =
[
    [ "System.Buffers.4.5.0", "dir_c6f6aeaa6a63f7609b44ede478804990.html", "dir_c6f6aeaa6a63f7609b44ede478804990" ],
    [ "System.Memory.4.5.3", "dir_5e42ac4dfe8a3f9f0d909cc6b34ee9dd.html", "dir_5e42ac4dfe8a3f9f0d909cc6b34ee9dd" ],
    [ "System.Numerics.Vectors.4.5.0", "dir_0e4681033ece62a049339cfa15a45fdb.html", "dir_0e4681033ece62a049339cfa15a45fdb" ],
    [ "System.Runtime.CompilerServices.Unsafe.4.7.0", "dir_79575e839b07f3b06513b12b9ec6e277.html", "dir_79575e839b07f3b06513b12b9ec6e277" ]
];