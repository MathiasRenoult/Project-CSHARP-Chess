var dir_5e42ac4dfe8a3f9f0d909cc6b34ee9dd =
[
    [ "LICENSE.TXT", "_system_8_memory_84_85_83_2_l_i_c_e_n_s_e_8txt_source.html", null ],
    [ "THIRD-PARTY-NOTICES.TXT", "_system_8_memory_84_85_83_2_t_h_i_r_d-_p_a_r_t_y-_n_o_t_i_c_e_s_8_t_x_t_source.html", null ]
];