var class_chess_1_1_queen =
[
    [ "Queen", "class_chess_1_1_queen.html#ae9bc991658b1b10c8ed9a810d5cfa484", null ],
    [ "CanMoveThere", "class_chess_1_1_queen.html#afe8fdb2bfa782831b3ce9b155428e969", null ]
];