var class_chess_1_1_knight =
[
    [ "Knight", "class_chess_1_1_knight.html#a1efe092286bbc7723ec68a1d14daf793", null ],
    [ "CanMoveThere", "class_chess_1_1_knight.html#a71f32fbf798977ae8a85b23a7b667da9", null ]
];