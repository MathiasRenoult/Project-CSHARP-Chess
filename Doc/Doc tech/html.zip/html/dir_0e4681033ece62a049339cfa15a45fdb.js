var dir_0e4681033ece62a049339cfa15a45fdb =
[
    [ "LICENSE.TXT", "_system_8_numerics_8_vectors_84_85_80_2_l_i_c_e_n_s_e_8txt_source.html", null ],
    [ "THIRD-PARTY-NOTICES.TXT", "_system_8_numerics_8_vectors_84_85_80_2_t_h_i_r_d-_p_a_r_t_y-_n_o_t_i_c_e_s_8_t_x_t_source.html", null ]
];