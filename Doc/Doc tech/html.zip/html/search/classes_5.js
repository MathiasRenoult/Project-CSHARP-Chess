var searchData=
[
  ['initialisingboard_50',['InitialisingBoard',['../class_chess_tests_1_1_initialising_board.html',1,'ChessTests']]]
];
