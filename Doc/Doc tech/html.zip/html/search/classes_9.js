var searchData=
[
  ['pawn_56',['Pawn',['../class_chess_1_1_pawn.html',1,'Chess']]],
  ['piece_57',['Piece',['../class_chess_1_1_piece.html',1,'Chess']]]
];
