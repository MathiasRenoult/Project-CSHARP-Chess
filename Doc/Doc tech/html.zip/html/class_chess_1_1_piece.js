var class_chess_1_1_piece =
[
    [ "Piece", "class_chess_1_1_piece.html#a9ea258cc9200797929ea6f9c82fa3c8c", null ],
    [ "CanMoveThere", "class_chess_1_1_piece.html#aa63fa73be6b7f325aaddbeaab10235c6", null ],
    [ "DeepCopy", "class_chess_1_1_piece.html#a8acea0fea894473c485422e7ac0aec00", null ],
    [ "giveDirection", "class_chess_1_1_piece.html#a397aadabca0411458f30d99d466a2a21", null ],
    [ "IsChecked", "class_chess_1_1_piece.html#acd44587878fc3ba6ee73baaecfd7ff5d", null ],
    [ "IsCheckMated", "class_chess_1_1_piece.html#a7aa4ebee73e64f245a657e595933e828", null ],
    [ "Color", "class_chess_1_1_piece.html#a9d91508d1f33e9c6f4363bdecde17088", null ],
    [ "IsChecking", "class_chess_1_1_piece.html#a537967b9f056efdf7140f8a2f8db2516", null ],
    [ "NbrOfMoves", "class_chess_1_1_piece.html#a7e04978ca3220ebc145339ce4980be46", null ],
    [ "X", "class_chess_1_1_piece.html#a66b695a40bf9640795f35b2fbe942d4f", null ],
    [ "Y", "class_chess_1_1_piece.html#a7cd0fed68cbf0e2d69983bdb5ef4f698", null ]
];