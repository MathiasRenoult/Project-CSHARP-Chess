var class_chess_1_1_u_i_test =
[
    [ "ConfirmPassword", "class_chess_1_1_u_i_test.html#a9954302dc8112026b7f7b5b586aaf37f", null ],
    [ "ConfirmPasswordFalse", "class_chess_1_1_u_i_test.html#aba4c4819301caa25b1dd877c380e2d99", null ],
    [ "FakePassword", "class_chess_1_1_u_i_test.html#a5aefc7ad81964927ec9b64b7c6124f2b", null ],
    [ "RegisterPasswordIsCorrect", "class_chess_1_1_u_i_test.html#ae7d5c91d3bd4b45240cfc7e3a21fc5ce", null ],
    [ "RegisterPasswordShort", "class_chess_1_1_u_i_test.html#ab991ed072de361a82066f9b5e9815fb4", null ],
    [ "RegisterWithoutMail", "class_chess_1_1_u_i_test.html#a8dc9024843db502f93b9c861f2e05b86", null ],
    [ "TestLoginIsCorrect", "class_chess_1_1_u_i_test.html#af2cceb3f0769e9e7acb22dd0908e41cc", null ],
    [ "TestLoginIsFailed", "class_chess_1_1_u_i_test.html#a112dbb6e44d9611f92964127153796fd", null ],
    [ "TestRegisterCorrect", "class_chess_1_1_u_i_test.html#a578884a15f6cefb9168cea34b9a2a16e", null ]
];