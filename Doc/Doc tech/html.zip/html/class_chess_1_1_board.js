var class_chess_1_1_board =
[
    [ "Board", "class_chess_1_1_board.html#a6be1b9cad1914b0156f937925fc225f0", null ],
    [ "clearBoard", "class_chess_1_1_board.html#a6c027312e426ea2c3af48be888370bdb", null ],
    [ "NewTurn", "class_chess_1_1_board.html#a2aabfb94bd3bd579d33f13c7df882496", null ],
    [ "placePieces", "class_chess_1_1_board.html#a765d3d8bc7199b6700dffce95a7768ca", null ],
    [ "ComputerDifficulty", "class_chess_1_1_board.html#a286c1c1da1e87a15d8dcac6317fbcb46", null ],
    [ "Grid", "class_chess_1_1_board.html#a228036669bba3d046afdcef5d641a4e4", null ],
    [ "SelectedTurn", "class_chess_1_1_board.html#a67f140e5929ed8a4fad241afb15cb237", null ],
    [ "Size", "class_chess_1_1_board.html#aee8902aa152e54869e06dbb0bf417447", null ]
];