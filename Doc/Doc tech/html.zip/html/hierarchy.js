var hierarchy =
[
    [ "ChessTests.AdddingPieces", "class_chess_tests_1_1_addding_pieces.html", null ],
    [ "Chess.Board", "class_chess_1_1_board.html", null ],
    [ "Chess.Case", "class_chess_1_1_case.html", null ],
    [ "Chess.ConnectToDB", "class_chess_1_1_connect_to_d_b.html", null ],
    [ "Chess.CryptoPassword", "class_chess_1_1_crypto_password.html", null ],
    [ "Chess.DatabaseConfig", "class_chess_1_1_database_config.html", null ],
    [ "ChessUI.DatabaseConfig", "class_chess_u_i_1_1_database_config.html", null ],
    [ "Form", null, [
      [ "Chess.GameForm", "class_chess_1_1_game_form.html", null ],
      [ "Chess.LoginForm", "class_chess_1_1_login_form.html", null ],
      [ "Chess.RegisterForm", "class_chess_1_1_register_form.html", null ],
      [ "ChessUI.ChangeDBConfigForm", "class_chess_u_i_1_1_change_d_b_config_form.html", null ]
    ] ],
    [ "ChessTests.InitialisingBoard", "class_chess_tests_1_1_initialising_board.html", null ],
    [ "ChessUI.Login", "class_chess_u_i_1_1_login.html", null ],
    [ "ChessTests.MovingPieces", "class_chess_tests_1_1_moving_pieces.html", null ],
    [ "Chess.Piece", "class_chess_1_1_piece.html", [
      [ "Chess.Bishop", "class_chess_1_1_bishop.html", null ],
      [ "Chess.King", "class_chess_1_1_king.html", null ],
      [ "Chess.Knight", "class_chess_1_1_knight.html", null ],
      [ "Chess.Pawn", "class_chess_1_1_pawn.html", null ],
      [ "Chess.Queen", "class_chess_1_1_queen.html", null ],
      [ "Chess.Rook", "class_chess_1_1_rook.html", null ],
      [ "Chess.VoidCase", "class_chess_1_1_void_case.html", null ]
    ] ],
    [ "ChessUI.Register", "class_chess_u_i_1_1_register.html", null ],
    [ "Chess.UITest", "class_chess_1_1_u_i_test.html", null ]
];