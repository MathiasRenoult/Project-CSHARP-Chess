var class_chess_1_1_pawn =
[
    [ "Pawn", "class_chess_1_1_pawn.html#a9650825385a066185bc294d8b386b162", null ],
    [ "CanMoveThere", "class_chess_1_1_pawn.html#a438fa1f02ab313754f720b9a3d082606", null ]
];