var class_chess_1_1_database_config =
[
    [ "DatabaseConfig", "class_chess_1_1_database_config.html#a732afb99e307cf64f67ab51eb99e2657", null ],
    [ "Db", "class_chess_1_1_database_config.html#aa254b5b0e331b855944cc8598fa2e81e", null ],
    [ "Password", "class_chess_1_1_database_config.html#abb145a65eb8393434d83845b45acd6c0", null ],
    [ "Server", "class_chess_1_1_database_config.html#ac2d77c72b09d15cdc9309800aeefe6a7", null ],
    [ "Uid", "class_chess_1_1_database_config.html#abfe2d5134ee8ccda39751042b9ad915f", null ]
];