var searchData=
[
  ['register_59',['Register',['../class_chess_u_i_1_1_register.html',1,'ChessUI']]],
  ['registerform_60',['RegisterForm',['../class_chess_1_1_register_form.html',1,'Chess']]],
  ['rook_61',['Rook',['../class_chess_1_1_rook.html',1,'Chess']]]
];
