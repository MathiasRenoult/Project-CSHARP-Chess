var searchData=
[
  ['dispose_71',['Dispose',['../class_chess_u_i_1_1_change_d_b_config_form.html#a481517d1d3e122fae732004c8bb3b057',1,'ChessUI.ChangeDBConfigForm.Dispose()'],['../class_chess_1_1_game_form.html#acae6ab07cd3d436d98af808a7f3170aa',1,'Chess.GameForm.Dispose()'],['../class_chess_1_1_login_form.html#ada7374d9a906be49bb4f145193dc8ada',1,'Chess.LoginForm.Dispose()'],['../class_chess_1_1_register_form.html#aea3c3a5140c8ea829e95a188dafc21ca',1,'Chess.RegisterForm.Dispose()']]]
];
