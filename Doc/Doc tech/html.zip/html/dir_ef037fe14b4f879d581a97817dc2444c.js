var dir_ef037fe14b4f879d581a97817dc2444c =
[
    [ "obj", "dir_e82ea916d21f07d111faba18603e0e16.html", "dir_e82ea916d21f07d111faba18603e0e16" ],
    [ "Properties", "dir_5f2ffb4fcdaaef4b71cabf85feeae7b7.html", "dir_5f2ffb4fcdaaef4b71cabf85feeae7b7" ],
    [ "MovingPieces.cs", "_moving_pieces_8cs_source.html", null ],
    [ "TestsAddingPieces.cs", "_tests_adding_pieces_8cs_source.html", null ],
    [ "TestsInitializingBoard.cs", "_tests_initializing_board_8cs_source.html", null ]
];