var searchData=
[
  ['pawn_30',['Pawn',['../class_chess_1_1_pawn.html',1,'Chess']]],
  ['piece_31',['Piece',['../class_chess_1_1_piece.html',1,'Chess']]],
  ['placepieces_32',['placePieces',['../class_chess_1_1_board.html#a765d3d8bc7199b6700dffce95a7768ca',1,'Chess::Board']]]
];
