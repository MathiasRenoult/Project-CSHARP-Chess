var dir_5f2ffb4fcdaaef4b71cabf85feeae7b7 =
[
    [ "AssemblyInfo.cs", "_chess_tests_2_properties_2_assembly_info_8cs_source.html", null ]
];