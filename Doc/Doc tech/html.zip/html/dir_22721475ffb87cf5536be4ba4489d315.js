var dir_22721475ffb87cf5536be4ba4489d315 =
[
    [ "AssemblyInfo.cs", "_chess_2_properties_2_assembly_info_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_properties_2_resources_8_designer_8cs_source.html", null ],
    [ "Settings.Designer.cs", "_properties_2_settings_8_designer_8cs_source.html", null ]
];