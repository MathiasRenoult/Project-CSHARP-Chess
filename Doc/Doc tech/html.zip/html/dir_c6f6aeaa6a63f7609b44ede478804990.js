var dir_c6f6aeaa6a63f7609b44ede478804990 =
[
    [ "LICENSE.TXT", "_system_8_buffers_84_85_80_2_l_i_c_e_n_s_e_8txt_source.html", null ],
    [ "THIRD-PARTY-NOTICES.TXT", "_system_8_buffers_84_85_80_2_t_h_i_r_d-_p_a_r_t_y-_n_o_t_i_c_e_s_8_t_x_t_source.html", null ]
];