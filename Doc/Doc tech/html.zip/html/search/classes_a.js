var searchData=
[
  ['queen_58',['Queen',['../class_chess_1_1_queen.html',1,'Chess']]]
];
