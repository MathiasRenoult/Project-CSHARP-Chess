var dir_621767255f74bc7edc92694b7cc649f8 =
[
    [ "Chess", "dir_1becf3e5976b3df21ed0999e4862a584.html", "dir_1becf3e5976b3df21ed0999e4862a584" ],
    [ "ChessTests", "dir_ef037fe14b4f879d581a97817dc2444c.html", "dir_ef037fe14b4f879d581a97817dc2444c" ],
    [ "ChessUI", "dir_b57d01c3a3f42ab9e1f33a883bdde504.html", "dir_b57d01c3a3f42ab9e1f33a883bdde504" ],
    [ "packages", "dir_a5bf77af11d82fb2d297ecf6b9f686eb.html", "dir_a5bf77af11d82fb2d297ecf6b9f686eb" ],
    [ "UIChessTests", "dir_77c65f73dc503441ff169288cc0f9b71.html", "dir_77c65f73dc503441ff169288cc0f9b71" ]
];