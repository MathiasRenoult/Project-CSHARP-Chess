/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Projet C#", "index.html", [
    [ "The Bouncy Castle Crypto Package For C Sharp", "md__c_1__users__romain_8_o_n_r_u_b_i_a__documents__git_kraken__chess__project-_c_s_h_a_r_p-_ches8839098b135abfcd2a11b435e434a155.html", [
      [ "Mailing Lists", "md__c_1__users__romain_8_o_n_r_u_b_i_a__documents__git_kraken__chess__project-_c_s_h_a_r_p-_ches8839098b135abfcd2a11b435e434a155.html#autotoc_md1", null ],
      [ "Feedback", "md__c_1__users__romain_8_o_n_r_u_b_i_a__documents__git_kraken__chess__project-_c_s_h_a_r_p-_ches8839098b135abfcd2a11b435e434a155.html#autotoc_md2", null ],
      [ "Finally", "md__c_1__users__romain_8_o_n_r_u_b_i_a__documents__git_kraken__chess__project-_c_s_h_a_r_p-_ches8839098b135abfcd2a11b435e434a155.html#autotoc_md3", null ]
    ] ],
    [ "LICENSE", "md__c_1__users__romain_8_o_n_r_u_b_i_a__documents__git_kraken__chess__project-_c_s_h_a_r_p-_ches5d8216f40b11291ba894136f727d78ca.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_board_8cs_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';