var searchData=
[
  ['databaseconfig_48',['DatabaseConfig',['../class_chess_1_1_database_config.html',1,'Chess.DatabaseConfig'],['../class_chess_u_i_1_1_database_config.html',1,'ChessUI.DatabaseConfig']]]
];
