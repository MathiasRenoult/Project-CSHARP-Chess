var searchData=
[
  ['king_51',['King',['../class_chess_1_1_king.html',1,'Chess']]],
  ['knight_52',['Knight',['../class_chess_1_1_knight.html',1,'Chess']]]
];
