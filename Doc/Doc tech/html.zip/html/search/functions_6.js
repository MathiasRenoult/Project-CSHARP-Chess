var searchData=
[
  ['openconnection_77',['OpenConnection',['../class_chess_1_1_connect_to_d_b.html#aa8abde2040302cd05e965c523e735ec3',1,'Chess::ConnectToDB']]]
];
