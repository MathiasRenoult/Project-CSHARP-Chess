var namespaces_dup =
[
    [ "Chess", "namespace_chess.html", "namespace_chess" ],
    [ "ChessTests", "namespace_chess_tests.html", null ],
    [ "ChessUI", "namespace_chess_u_i.html", "namespace_chess_u_i" ]
];