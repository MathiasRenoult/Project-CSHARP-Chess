var searchData=
[
  ['bishop_42',['Bishop',['../class_chess_1_1_bishop.html',1,'Chess']]],
  ['board_43',['Board',['../class_chess_1_1_board.html',1,'Chess']]]
];
