var dir_80caa0820c72ca5e3c35acf1a0e6b931 =
[
    [ "AssemblyInfo.cs", "_u_i_chess_tests_2_properties_2_assembly_info_8cs_source.html", null ]
];