var searchData=
[
  ['movingpieces_28',['MovingPieces',['../class_chess_tests_1_1_moving_pieces.html',1,'ChessTests']]]
];
