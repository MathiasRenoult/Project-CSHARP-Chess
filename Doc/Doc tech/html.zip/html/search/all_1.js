var searchData=
[
  ['bishop_2',['Bishop',['../class_chess_1_1_bishop.html',1,'Chess']]],
  ['board_3',['Board',['../class_chess_1_1_board.html',1,'Chess']]]
];
