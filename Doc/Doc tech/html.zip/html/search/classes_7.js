var searchData=
[
  ['login_53',['Login',['../class_chess_u_i_1_1_login.html',1,'ChessUI']]],
  ['loginform_54',['LoginForm',['../class_chess_1_1_login_form.html',1,'Chess']]]
];
