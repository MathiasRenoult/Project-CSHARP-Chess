var class_chess_1_1_game_form =
[
    [ "GameForm", "class_chess_1_1_game_form.html#a500b4a4e8ef3d644f6fbb2438fd20fff", null ],
    [ "Dispose", "class_chess_1_1_game_form.html#acae6ab07cd3d436d98af808a7f3170aa", null ],
    [ "DrawGrid", "class_chess_1_1_game_form.html#afdb3969413da2a9971da2ef467323edf", null ],
    [ "FunnyColors", "class_chess_1_1_game_form.html#a60c5597e77c4da9ee4f2dd4e533dd3a0", null ],
    [ "GetColorValue", "class_chess_1_1_game_form.html#aed39ef49b2cb79b24701064799d28012", null ],
    [ "InitTimer", "class_chess_1_1_game_form.html#a8becb71577e8cda187d34ed47e3c9e2c", null ],
    [ "MainBoard", "class_chess_1_1_game_form.html#a3283fd0ec437a85e3427837f30f56526", null ]
];