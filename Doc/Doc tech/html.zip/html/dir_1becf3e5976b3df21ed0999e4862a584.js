var dir_1becf3e5976b3df21ed0999e4862a584 =
[
    [ "obj", "dir_1fba7f0fe508049e6ba3e1a57909f345.html", "dir_1fba7f0fe508049e6ba3e1a57909f345" ],
    [ "Properties", "dir_22721475ffb87cf5536be4ba4489d315.html", "dir_22721475ffb87cf5536be4ba4489d315" ],
    [ "Board.cs", "_board_8cs_source.html", null ],
    [ "Case.cs", "_case_8cs_source.html", null ],
    [ "ConnectToDB.cs", "_connect_to_d_b_8cs_source.html", null ],
    [ "DatabaseConfig.cs", "_database_config_8cs_source.html", null ],
    [ "Hashing.cs", "_hashing_8cs_source.html", null ],
    [ "Piece.cs", "_piece_8cs_source.html", null ],
    [ "PiecesTypes.cs", "_pieces_types_8cs_source.html", null ],
    [ "Program.cs", "_program_8cs_source.html", null ]
];