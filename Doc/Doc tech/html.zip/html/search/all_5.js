var searchData=
[
  ['initialisingboard_19',['InitialisingBoard',['../class_chess_tests_1_1_initialising_board.html',1,'ChessTests']]],
  ['ischecked_20',['IsChecked',['../class_chess_1_1_piece.html#acd44587878fc3ba6ee73baaecfd7ff5d',1,'Chess.Piece.IsChecked()'],['../class_chess_1_1_king.html#ab397d687e6cfd48f911f6a982131b1d8',1,'Chess.King.IsChecked()']]],
  ['ischeckmated_21',['IsCheckMated',['../class_chess_1_1_piece.html#a7aa4ebee73e64f245a657e595933e828',1,'Chess.Piece.IsCheckMated()'],['../class_chess_1_1_king.html#a12efcf63f3b36a320365654cdb3eecee',1,'Chess.King.IsCheckMated()']]]
];
