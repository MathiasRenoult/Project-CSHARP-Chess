var searchData=
[
  ['adddingpieces_41',['AdddingPieces',['../class_chess_tests_1_1_addding_pieces.html',1,'ChessTests']]]
];
