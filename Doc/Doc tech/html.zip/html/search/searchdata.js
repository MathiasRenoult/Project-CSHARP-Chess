var indexSectionsWithContent =
{
  0: "abcdgiklmopqrtuv",
  1: "abcdgiklmpqruv",
  2: "c",
  3: "acdgilopv",
  4: "lt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Pages"
};

