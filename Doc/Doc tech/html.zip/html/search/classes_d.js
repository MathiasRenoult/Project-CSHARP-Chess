var searchData=
[
  ['voidcase_63',['VoidCase',['../class_chess_1_1_void_case.html',1,'Chess']]]
];
