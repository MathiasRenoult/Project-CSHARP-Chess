var searchData=
[
  ['loginplayer_76',['LoginPlayer',['../class_chess_1_1_connect_to_d_b.html#a10db76401c3f7af289cdc729449840fa',1,'Chess::ConnectToDB']]]
];
