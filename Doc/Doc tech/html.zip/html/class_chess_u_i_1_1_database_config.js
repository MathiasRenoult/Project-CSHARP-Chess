var class_chess_u_i_1_1_database_config =
[
    [ "DatabaseConfig", "class_chess_u_i_1_1_database_config.html#a3cdf805c1fe177b42b88d422986b2763", null ],
    [ "Db", "class_chess_u_i_1_1_database_config.html#afd49ed7a6db4ef7399ea59761756351e", null ],
    [ "Password", "class_chess_u_i_1_1_database_config.html#a45abb831fcc71f83b74fda66bc22e5cb", null ],
    [ "Server", "class_chess_u_i_1_1_database_config.html#a3e19f4cbf96a520e3c78de5fac00a06b", null ],
    [ "Uid", "class_chess_u_i_1_1_database_config.html#a862ce2af70281862451d84a75d74e143", null ]
];