var class_chess_1_1_connect_to_d_b =
[
    [ "ConnectToDB", "class_chess_1_1_connect_to_d_b.html#a6f20cf0063ad39dce8daae903e2bce24", null ],
    [ "AddPlayer", "class_chess_1_1_connect_to_d_b.html#a4c52874ae1470b024ab92df0ebc2f634", null ],
    [ "CloseConnection", "class_chess_1_1_connect_to_d_b.html#a4fcc9ac406552ec262f2448a3dd76cdc", null ],
    [ "GetPlayerName", "class_chess_1_1_connect_to_d_b.html#a425b7af4d6f6b0d88a4e112b9a7394c5", null ],
    [ "LoginPlayer", "class_chess_1_1_connect_to_d_b.html#a10db76401c3f7af289cdc729449840fa", null ],
    [ "OpenConnection", "class_chess_1_1_connect_to_d_b.html#aa8abde2040302cd05e965c523e735ec3", null ]
];