var searchData=
[
  ['king_22',['King',['../class_chess_1_1_king.html',1,'Chess']]],
  ['knight_23',['Knight',['../class_chess_1_1_knight.html',1,'Chess']]]
];
