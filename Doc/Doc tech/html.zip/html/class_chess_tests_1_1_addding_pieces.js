var class_chess_tests_1_1_addding_pieces =
[
    [ "AddingBishop", "class_chess_tests_1_1_addding_pieces.html#a0bd9bf6d81c4082518d7d3ac0a0e2ba7", null ],
    [ "AddingKing", "class_chess_tests_1_1_addding_pieces.html#a5ce5f741d21fd794d2a36198211ffa48", null ],
    [ "AddingKnight", "class_chess_tests_1_1_addding_pieces.html#a2431a6ab43bbff04081ff8e34369cb95", null ],
    [ "AddingPawn", "class_chess_tests_1_1_addding_pieces.html#a131ed2e97afd8a3064ccc8bdba2fc9df", null ],
    [ "AddingQueen", "class_chess_tests_1_1_addding_pieces.html#a3a331d166700f44737326a9a6fe7e79b", null ],
    [ "AddingRook", "class_chess_tests_1_1_addding_pieces.html#abf62e6df156c35849874f938ff7ae233", null ]
];