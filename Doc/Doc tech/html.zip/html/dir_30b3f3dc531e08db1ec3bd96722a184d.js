var dir_30b3f3dc531e08db1ec3bd96722a184d =
[
    [ "AssemblyInfo.cs", "_chess_u_i_2_properties_2_assembly_info_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_i_2_properties_2_resources_8_designer_8cs_source.html", null ],
    [ "Settings.Designer.cs", "_i_2_properties_2_settings_8_designer_8cs_source.html", null ]
];