var dir_7ce97f6707b01000879d6269b637f14d =
[
    [ "GitKraken", "dir_f120ba0af5c4d37ecad63286fa24972a.html", "dir_f120ba0af5c4d37ecad63286fa24972a" ]
];