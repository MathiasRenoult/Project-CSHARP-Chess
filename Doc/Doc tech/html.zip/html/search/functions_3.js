var searchData=
[
  ['getplayername_72',['GetPlayerName',['../class_chess_1_1_connect_to_d_b.html#a425b7af4d6f6b0d88a4e112b9a7394c5',1,'Chess::ConnectToDB']]],
  ['givedirection_73',['giveDirection',['../class_chess_1_1_piece.html#a397aadabca0411458f30d99d466a2a21',1,'Chess::Piece']]]
];
