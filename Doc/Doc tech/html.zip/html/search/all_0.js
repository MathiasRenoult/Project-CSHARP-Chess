var searchData=
[
  ['adddingpieces_0',['AdddingPieces',['../class_chess_tests_1_1_addding_pieces.html',1,'ChessTests']]],
  ['addplayer_1',['AddPlayer',['../class_chess_1_1_connect_to_d_b.html#a4c52874ae1470b024ab92df0ebc2f634',1,'Chess::ConnectToDB']]]
];
