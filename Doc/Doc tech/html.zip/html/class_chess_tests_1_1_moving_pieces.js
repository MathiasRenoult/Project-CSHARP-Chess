var class_chess_tests_1_1_moving_pieces =
[
    [ "TestKnightMoves", "class_chess_tests_1_1_moving_pieces.html#ad1da7d5d7dc633af95eca62face4961f", null ],
    [ "TestPawnMoves", "class_chess_tests_1_1_moving_pieces.html#aa034921e3cc9091fcc28865c205d1344", null ]
];