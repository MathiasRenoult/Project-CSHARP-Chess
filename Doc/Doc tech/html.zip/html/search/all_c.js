var searchData=
[
  ['register_34',['Register',['../class_chess_u_i_1_1_register.html',1,'ChessUI']]],
  ['registerform_35',['RegisterForm',['../class_chess_1_1_register_form.html',1,'Chess']]],
  ['rook_36',['Rook',['../class_chess_1_1_rook.html',1,'Chess']]]
];
