var dir_f93d20653cc1a72b7228704a24250240 =
[
    [ "Project-CSHARP-Chess", "dir_cbd18c7385eb1efff61f2bb09f5b908c.html", "dir_cbd18c7385eb1efff61f2bb09f5b908c" ]
];