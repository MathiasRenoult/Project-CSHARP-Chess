var namespace_chess_u_i =
[
    [ "ChangeDBConfigForm", "class_chess_u_i_1_1_change_d_b_config_form.html", "class_chess_u_i_1_1_change_d_b_config_form" ],
    [ "DatabaseConfig", "class_chess_u_i_1_1_database_config.html", "class_chess_u_i_1_1_database_config" ],
    [ "Login", "class_chess_u_i_1_1_login.html", null ],
    [ "Register", "class_chess_u_i_1_1_register.html", null ]
];